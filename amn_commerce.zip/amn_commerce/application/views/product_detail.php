<table width="100%" border="0" cellpadding="10">
  <tr>
    <td width="15">&nbsp;</td>
    <td colspan="3"><?php echo $product_detail->product_name; ?></td>
    <td width="15">&nbsp;</td>
  </tr>
  <tr>
    <td height="10"></td>
    <td width="188"></td>
    <td width="5"></td>
    <td width="284"></td>
    <td>
    </td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td align="center" valign="top"><img src="<?php echo $product_detail->product_image; ?>" height="200px;" width="200px;" alt="" border="0" /></td>
    <td>&nbsp;</td>
    <td><div>Product Code: <br />
      Availability: In Stock</div>
      <div>Product Detail: <br/> <?php echo $product_detail->product_description; ?></div>
      <div>Price: <?php echo $product_detail->product_price; ?> Tk <br />
      </div>
      <div>
        <div>Qty:
          <input type="number" name="quantity" size="2" maxlength="6" value="" />
          <a id="button-cart">Add to Cart</a></div>
      </div>
      <div>
      <div><img src="http://www.meenabazar.com.bd/catalog/view/theme/default/image/stars-0.png" alt="0 reviews" />  <a onclick="$('a[href=\'#tab-review\']').trigger('click');">0 reviews</a>  |  <a onclick="$('a[href=\'#tab-review\']').trigger('click');">Write a review</a></div></td>
    <td>&nbsp;</td>
  </tr>
 <tr>
    <td height="10"></td>
    <td width="188"></td>
    <td width="5"></td>
    <td width="284"></td>
    <td>
    </td>
  </tr>
</table>